$(function () {
   
    $.ajax({
        url: "Clientes",
        success: function (data) {
            var fils = $.parseJSON(data);
            
            for (var idx in fils) {
                var fil = fils[idx];                
                
                $('#tbClientes > tbody:last-child').append('<tr>' +
                    '<td>' + fil.RUC+ '</td>' +
                    '<td>' + fil.Nombre + '</td>' +
                    '<td>' + fil.Sector + '</td>' +
                    '<td>' + fil.Direccion + '</td>' +
                    '<td>' + fil.Web + '</td>' + 
                    '<td><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalLong">  Ver</button></td>' + 
                 '</tr>');
               
                
            }
           
        }
    });
});