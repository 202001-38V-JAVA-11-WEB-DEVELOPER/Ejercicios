$(function () {
   
    $.ajax({
        url: "Proveedores",
        success: function (data) {
            var fils = $.parseJSON(data);
            
            for (var idx in fils) {
                var fil = fils[idx];                
                
                $('#tbClientes > tbody:last-child').append('<tr>' +
                    '<td>' + fil.Codigo+ '</td>' +
                    '<td>' + fil.Nombre + '</td>' +
                    '<td>' + fil.Direccion + '</td>' +
                    '<td>' + fil.Pais + '</td>' + 
                 '</tr>');
               
            }
           
        }
    });
});